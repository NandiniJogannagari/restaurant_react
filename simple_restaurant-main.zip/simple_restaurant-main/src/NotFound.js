import React from 'react'
import Header from './Container/Header'

const NotFound = () => {
  return (
    <div>
      <Header />
      <center>
        <h4 className='mt-3 text-primary'>Page Not Found 404</h4>
      </center>
    </div>
  )
}

export default NotFound
